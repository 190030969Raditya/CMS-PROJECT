package in.kpmg.cmsapi.Model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Data
@Entity
@Table(name = "EHFM_CR_ATTACHMENTS_MAPPING")
public class EHFM_CR_ATTACHMENTS_MAPPING_MODEL {
	@Id
	private Long CR_REQ_ID;
	private String ATTCH_FILE_DTLS;
	private Long ATTACHMENT_ORDER;
	private Long CRT_BY;
	@CreationTimestamp
    private Timestamp CRT_ON;
	

}
