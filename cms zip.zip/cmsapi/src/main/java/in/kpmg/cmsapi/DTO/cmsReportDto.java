package in.kpmg.cmsapi.DTO;

import lombok.Data;
@Data
public class cmsReportDto {

	
		private String fromDate;
		private String toDate; 
		private String State;
		
	


}
