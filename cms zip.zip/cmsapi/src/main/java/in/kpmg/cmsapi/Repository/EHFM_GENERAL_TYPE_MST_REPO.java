package in.kpmg.cmsapi.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.kpmg.cmsapi.Model.EHFM_GENERAL_TYPE_MST_MODEL;
@Repository

public interface  EHFM_GENERAL_TYPE_MST_REPO extends JpaRepository< EHFM_GENERAL_TYPE_MST_MODEL,Long>  {

}
