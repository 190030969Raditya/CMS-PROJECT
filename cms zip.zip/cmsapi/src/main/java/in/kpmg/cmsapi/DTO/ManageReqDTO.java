package in.kpmg.cmsapi.DTO;

import lombok.Data;

@Data
public class ManageReqDTO {
	private String fromDate;
	private String toDate; 
	private String applnType;
	private String orgName;
	private String deptName;
	
}
