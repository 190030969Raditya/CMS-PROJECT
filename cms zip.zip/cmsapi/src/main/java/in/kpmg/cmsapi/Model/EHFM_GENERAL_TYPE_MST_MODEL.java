package in.kpmg.cmsapi.Model;

import lombok.Data;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Table;

	@Data
	@Entity
	@Table(name = "EHFM_GENERAL_TYPE_MST")
	public class EHFM_GENERAL_TYPE_MST_MODEL {
	    @Id
	    private Long TYPE_ID;
	    private String TYPE_NAME;
	    @Column(name = "TYPE_DESC")
	    private String typeDesc;
	    private Character IS_ACTIVE;
	    private Long TYPE_ORDER;
	}

