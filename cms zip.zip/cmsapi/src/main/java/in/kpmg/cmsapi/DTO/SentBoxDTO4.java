package in.kpmg.cmsapi.DTO;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public interface SentBoxDTO4 {
	@JsonFormat(pattern="dd-MM-yyyy")
	Date getedd();

}
