package in.kpmg.cmsapi.DTO;

import lombok.Data;

@Data
public class EHFM_DEPARTMENT_MST_DTO {
	
	 private String deptNmae;
	 private String deptDesc;
	 private String isActive;
	 private String deptOrder;
	 private String isEnrollmentApplicable;
	 private String isCmsApplicable;
	 private String immdteParntDeptId;
	 
}
