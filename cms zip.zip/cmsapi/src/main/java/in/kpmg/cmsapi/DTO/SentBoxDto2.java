package in.kpmg.cmsapi.DTO;

public interface SentBoxDto2 {
	String getemp_code();
	String getemp_name();
	String getdesignation();

}
