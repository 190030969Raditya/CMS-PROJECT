package in.kpmg.cmsapi.Controller;

import java.util.List;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import in.kpmg.cmsapi.DTO.AdvanceReqId;
import in.kpmg.cmsapi.DTO.ApiResponse;
import in.kpmg.cmsapi.DTO.ApiResponse2;
import in.kpmg.cmsapi.DTO.EHFM_CHANGE_REQ_DETAILS_DTO;
import in.kpmg.cmsapi.DTO.EHFM_CR_ATTACHMENTS_MAPPING_DTO;
import in.kpmg.cmsapi.DTO.ManageReqDTO;
import in.kpmg.cmsapi.DTO.ManageReqResult;
import in.kpmg.cmsapi.DTO.MydeptReportDTO;
import in.kpmg.cmsapi.DTO.cmsReportDto;
import in.kpmg.cmsapi.DTO.cmsReportResult;
import in.kpmg.cmsapi.DTO.datesDTO;
import in.kpmg.cmsapi.DTO.myDeptReportResult;
import in.kpmg.cmsapi.Service.CreateCRService;
import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class CreateCRController {
	@Autowired
	 CreateCRService createcrservice;
	@GetMapping("/initiate-application")
    public ApiResponse2<?> initiateApplication() {
        return new ApiResponse2<>(true, "Details fetched successfully", createcrservice.initiateApplication());
    }
	
	@PostMapping("/save-request-details")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public ApiResponse2<?> saveEnrollDetails(@RequestBody EHFM_CHANGE_REQ_DETAILS_DTO ehfm_change_req_details_dto){
		log.info("Request received to save details");
		return createcrservice.saveApplicationForm(ehfm_change_req_details_dto);
	}
	
	@PostMapping("/inbox-searchbydate")
    public ApiResponse2<?> fetchinbox(@RequestBody datesDTO date){  
		return new ApiResponse2<>(true, "Details fetched successfully", createcrservice.fetchInbox(date.fromDate,date.toDate));
	}
	@PostMapping("/sentbox-searchbydate")
    public ApiResponse2<?> fetchsentbox(@RequestBody datesDTO date){  
		return new ApiResponse2<>(true, "Details fetched successfully", createcrservice.fetchSentbox(date.fromDate,date.toDate));
	}
	
	@GetMapping("/change-req-table")
    public ApiResponse2<?> changeReqTable(){  
		return new ApiResponse2<>(true, "Details fetched successfully", createcrservice.changeReqTable());
	}
		
	@GetMapping("/sentbox")
	   public ApiResponse2<?> fetchsentboxDetails(){
			return new ApiResponse2<>(true, "Details fetched successfully", createcrservice.fetchSentboxDetails());
	}
	
	@GetMapping("/inbox")
	   public ApiResponse2<?> fetchInboxDetails(){
			return new ApiResponse2<>(true, "Details fetched successfully", createcrservice.fetctInboxDetails());
	}

	@PostMapping(value = "/supporting-docs", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
	@CrossOrigin(origins = "*", allowedHeaders = "*")
    public ApiResponse2<?> saveApplicationForm(
					@RequestPart(value = "files") List<MultipartFile> files,
					@RequestPart(value = "ehfm_cr_attachmets_mapping_dto") List<EHFM_CR_ATTACHMENTS_MAPPING_DTO> ehfm_cr_attachmets_mapping_dto,
					@RequestPart(value = "crdto") EHFM_CR_ATTACHMENTS_MAPPING_DTO crdto)
					{

	log.info("Request received to save attach details");
	return createcrservice.supportingdocs(files,crdto,ehfm_cr_attachmets_mapping_dto);
	
	
	}
	
	
	 @PostMapping("/change-req-details")
	    public ApiResponse2<?> changeReqDetails(@RequestBody AdvanceReqId crReqId) {
	        return new ApiResponse2<>(true, "Search result found", createcrservice.changeReq(crReqId.getCrReqId()));
	    }
	
	@PostMapping("/manage-request")
	public ApiResponse<?> fetchDetails(@RequestBody ManageReqDTO request) {

			List<ManageReqResult> results = createcrservice.manageRequest(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(ManageReqResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getCrReqId());
	                jsonArray.put(position.getCrTitle());
	                jsonArray.put(position.getCrDesc());
	                jsonArray.put(position.getDeptName());
	                jsonArray.put(position.getCrtOn());
	                jsonArray.put(position.getEcd());
	                jsonArray.put(position.getCrStatus());
	                jsonArray.put(position.getSeverity());
	                jsonArray.put(position.getChangeType());
	                jsonArray.put(position.getUsername());
	                jsonArray.put(position.getWorkflowCat());
	                
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());

			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

	}
	@PostMapping("/mycms-report")
	public ApiResponse<?> mycmsreportsfetch(@RequestBody cmsReportDto request) {

			List<cmsReportResult> results = createcrservice.mycmsreport(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(cmsReportResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getCrReqId());
	                jsonArray.put(position.getCrTitle());
	                jsonArray.put(position.getCrDesc());
	                jsonArray.put(position.getDeptName());
	                jsonArray.put(position.getCrtOn());
	                jsonArray.put(position.getCrStatus());
	                jsonArray.put(position.getSeverity());
	                jsonArray.put(position.getChangeType());
	                jsonArray.put(position.getUsername());
	                jsonArray.put(position.getWorkflowCat());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());

			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

	}
	
	@PostMapping("/mydept-report")
	public ApiResponse<?> myDeptReportfetch(@RequestBody MydeptReportDTO request) {

			List<myDeptReportResult> results = createcrservice.myDeptReport(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(myDeptReportResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getCrReqId());
	                jsonArray.put(position.getCrTitle());
	                jsonArray.put(position.getCrDesc());
	                jsonArray.put(position.getDeptName());
	                jsonArray.put(position.getCrtOn());
	                jsonArray.put(position.getCrStatus());
	                jsonArray.put(position.getSeverity());
	                jsonArray.put(position.getChangeType());
	                jsonArray.put(position.getUsername());
	                jsonArray.put(position.getWorkflowCat());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());

			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

	}

}