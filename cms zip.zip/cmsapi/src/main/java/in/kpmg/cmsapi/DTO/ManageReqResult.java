package in.kpmg.cmsapi.DTO;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
public class ManageReqResult {
	@Id
	private Long crReqId;
	private String crTitle;
	private String crDesc;
	private String deptName;
	 @JsonFormat(shape= JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Timestamp crtOn;
	 @JsonFormat(shape= JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Timestamp ecd;
	private String crStatus;
	private String severity;
	private String changeType;
	private String username;
	private String workflowCat;
	
}
