package in.kpmg.cmsapi.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.kpmg.cmsapi.DTO.ChangeReqDto;
import in.kpmg.cmsapi.DTO.CodeValueResult;
import in.kpmg.cmsapi.DTO.InboxDTO;
import in.kpmg.cmsapi.DTO.SentBox6;
import in.kpmg.cmsapi.DTO.SentBoxDTO3;
import in.kpmg.cmsapi.DTO.SentBoxDTO4;
import in.kpmg.cmsapi.DTO.SentBoxDto2;
import in.kpmg.cmsapi.DTO.SentboxDTO;
import in.kpmg.cmsapi.DTO.SentboxDTO1;
import in.kpmg.cmsapi.Model.EHFM_CHANGE_REQ_DETAILS_MODEL;

@Repository
public interface EHFM_CHANGE_REQ_DETAILS_Repo  extends JpaRepository<EHFM_CHANGE_REQ_DETAILS_MODEL,Long>
{
//	@Query(value = "select * from EHFM_CHANGE_REQ_DTLS where cr_req_id=:id",nativeQuery = true)
//    List<EHFM_CHANGE_REQ_DETAILS_MODEL> findAllByRequestId(long id);
//	@Query(value="select APPLN_TYPE valueId,upper(APPLN_TYPE) valueName from EHFM_CHANGE_REQ_DTLS order by APPLN_TYPE",nativeQuery = true)
//	List<CodeValueResult> getApplicationType();
	@Query(value="select xyz.step_name status,crd.expected_completion_dt edt,crd.cr_req_id crReqId,crd.cr_title crTitle,crd.CR_DESC crDesc,dm.dept_name deptName,crd.crt_on crtOn,sm.Step_name stepName,gm.type_name typeName,gm1.type_name TypeNames,(us.first_name||' '||us.last_name)username,wm.WORKFLOW_NAME workflowName\r\n"
			+ "from ehs.ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm\r\n"
			+ "on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\r\n"
			+ "on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\r\n"
			+ "on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\r\n"
			+ "on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\r\n"
			+ "on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\r\n"
			+ "on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\r\n"
			+ "on crd.TYPE_OF_CHANGE = gm1.type_id left join ehs.EHFM_USERS us\r\n"
			+ "on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\r\n"
			+ "on crd.WORKFLOW_CAT = wm.WORKFLOW_ID left join ehs.EHFM_STEP_ROLE_MAPPING abc\r\n"
			+ "on crd.cr_status_id=abc.ID left join ehs.ehfm_step_mst xyz\r\n"
			+ "on abc.step_id = xyz.step_id\r\n"
			+ "where TO_CHAR(crd.crt_on, 'YYYY-MM-DD') >=:fromDate and TO_CHAR(crd.crt_on, 'YYYY-MM-DD') <=:toDate",nativeQuery = true)
	List<InboxDTO> getInboxData(@Param("fromDate") String fromDate, @Param("toDate") String toDate);
	
	@Query(value="select xyz.step_name status,crd.expected_completion_dt edt,crd.cr_req_id crReqId,crd.cr_title crTitle,crd.CR_DESC crDesc,dm.dept_name deptName,crd.crt_on crtOn,sm.Step_name stepName,gm.type_name typeName,gm1.type_name TypeNames,(us.first_name||' '||us.last_name)username,wm.WORKFLOW_NAME workflowName\r\n"
			+ "from ehs.ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm\r\n"
			+ "on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\r\n"
			+ "on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\r\n"
			+ "on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\r\n"
			+ "on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\r\n"
			+ "on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\r\n"
			+ "on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\r\n"
			+ "on crd.TYPE_OF_CHANGE = gm1.type_id left join ehs.EHFM_USERS us\r\n"
			+ "on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\r\n"
			+ "on crd.WORKFLOW_CAT = wm.WORKFLOW_ID left join ehs.EHFM_STEP_ROLE_MAPPING abc\r\n"
			+ "on crd.cr_status_id=abc.ID left join ehs.ehfm_step_mst xyz\r\n"
			+ "on abc.step_id = xyz.step_id\r\n"
			+ "where TO_CHAR(crd.crt_on, 'YYYY-MM-DD') >=:fromDate and TO_CHAR(crd.crt_on, 'YYYY-MM-DD') <=:toDate",nativeQuery = true)
	List<SentboxDTO> getSentboxData(@Param("fromDate") String fromDate, @Param("toDate") String toDate);
	
	@Query(value="select xyz.step_name status,crd.expected_completion_dt edt,crd.cr_req_id crReqId ,crd.cr_title crTitle,crd.CR_DESC crDesc,dm.dept_name deptName,crd.crt_on crtOn,sm.Step_name stepName,gm.type_name typeName,gm1.type_name TypeNames,(us.first_name||' '||us.last_name)username,wm.WORKFLOW_NAME workflowName\r\n"
			+ "			from ehs.ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm\r\n"
			+ "			on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\r\n"
			+ "		on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\r\n"
			+ "			on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\r\n"
			+ "			on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\r\n"
			+ "			on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\r\n"
			+ "			on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\r\n"
			+ "			on crd.TYPE_OF_CHANGE = gm1.type_id left join ehs.EHFM_USERS us\r\n"
			+ "			on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\r\n"
			+ "			on crd.WORKFLOW_CAT = wm.WORKFLOW_ID left join ehs.EHFM_STEP_ROLE_MAPPING abc\r\n"
			+ "			on crd.cr_status_id=abc.ID left join ehs.ehfm_step_mst xyz\r\n"
			+ "			on abc.step_id = xyz.step_id\r\n"
			+ "			ORDER BY crReqId DESC;",nativeQuery = true)
	List<SentboxDTO> getSentbox();
	
	@Query(value="select xyz.step_name status,crd.expected_completion_dt edt,crd.cr_req_id crReqId ,crd.cr_title crTitle,crd.CR_DESC crDesc,dm.dept_name deptName,crd.crt_on crtOn,sm.Step_name stepName,gm.type_name typeName,gm1.type_name TypeNames,(us.first_name||' '||us.last_name)username,wm.WORKFLOW_NAME workflowName\r\n"
			+ "			from ehs.ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm\r\n"
			+ "			on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\r\n"
			+ "		on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\r\n"
			+ "			on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\r\n"
			+ "			on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\r\n"
			+ "			on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\r\n"
			+ "			on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\r\n"
			+ "			on crd.TYPE_OF_CHANGE = gm1.type_id left join ehs.EHFM_USERS us\r\n"
			+ "			on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\r\n"
			+ "			on crd.WORKFLOW_CAT = wm.WORKFLOW_ID left join ehs.EHFM_STEP_ROLE_MAPPING abc\r\n"
			+ "			on crd.cr_status_id=abc.ID left join ehs.ehfm_step_mst xyz\r\n"
			+ "			on abc.step_id = xyz.step_id\r\n"
			+ "			ORDER BY crReqId DESC;",nativeQuery = true)
	List<InboxDTO> getInbox();
	
	@Query(value="select eu.login_name EmployeeCode,eu.first_name || eu.last_name ActionTakenBy,eu.mobile_no Phonenumber,edm.desgn_name desgnname,crd.remarks remarks,crd.upd_on ActionTakenTime,cam.attch_file_dtls viewattchments,abc.step_name status \r\n"
			+ "from ehs.ehfm_change_req_dtls crd left join ehs.ehfm_users eu\r\n"
			+ "on crd.upd_by = eu.user_id left join ehs.ehfm_designation_mst edm\r\n"
			+ "on eu.desgn_id = edm.desgn_id left join ehs.ehfm_cr_attachments_mapping cam\r\n"
			+ "on crd.cr_req_id =cam.cr_req_id left join ehs.EHFM_STEP_MST abc \r\n"
			+ "on crd.cr_status_id=abc.STEP_ID",nativeQuery = true)
	List<ChangeReqDto> getchangeReqTable();
	
	@Query(value="SELECT eu.first_name || eu.last_name empname,edm.desgn_name desgn,eu.login_name username,eu.email EmailId,mobile_no MobileNo FROM ehs.ehfm_users eu left join ehs.ehfm_designation_mst edm on eu.desgn_id = edm.desgn_id",nativeQuery = true)
	List<SentBoxDTO3> getProfileData();
	
	
	@Query(value="select cr.CR_STATUS_ID RequestId,abc.step_name Status from ehs.EHFM_CHANGE_REQ_DTLS cr left join ehs.EHFM_STEP_MST abc on cr.cr_status_id=abc.STEP_ID order by RequestId ",nativeQuery = true)
	List<SentboxDTO1> getStatus();
	
	@Query(value="select ORG_ID valueId,upper(ORG_NAME) valueName from ehs.ehfm_org_mst where org_id = 3 and is_active_org='Y' order by ORG_NAME",nativeQuery = true)
	List<CodeValueResult> getOrgType();
	
	@Query(value="select DEPT_ID valueId,upper(DEPT_NAME) valueName from ehs.ehfm_department_mst where is_active='Y' order by DEPT_ORDER",nativeQuery = true)
	List<CodeValueResult> getDeptType();
	@Query(value="select dept_id valueID,upper(DEPT_NAME) valueName from ehs.ehfm_department_mst where is_active='Y' order by DEPT_ORDER",nativeQuery = true)
	List<CodeValueResult> getDeptName();
	
	@Query(value="select MODULE_ID valueId,upper(MODULE_NAME) valueName from ehs.ehfm_module_mst where is_active='Y' order by MODULE_NAME",nativeQuery = true)
	List<CodeValueResult> getCRModule();
	@Query(value="select CR_REQ_ID valueId from ehs.EHFM_CHANGE_REQ_DTLS;",nativeQuery = true)
	List<CodeValueResult> getCRId();
	
	@Query(value="select TYPE_ID valueId,upper(TYPE_NAME) valueName from ehs.ehfm_general_type_mst where is_active='Y' and TYPE_ID between 42 and 49 order by TYPE_ORDER",nativeQuery = true)
	List<CodeValueResult> getTypeOfChange();
	
	@Query(value="select expected_completion_dt edd from ehs.ehfm_change_req_dtls",nativeQuery = true)
	List<SentBoxDTO4> getExpectedDt();
	
	@Query(value="select TYPE_ID valueId,upper(TYPE_NAME) valueName from ehs.ehfm_general_type_mst where is_active='Y' and type_id between 39 and 41 order by TYPE_ORDER",nativeQuery = true)
	List<CodeValueResult> getTypeOfSeverity();
	
	@Query(value="select WORKFLOW_ID valueId,upper(WORKFLOW_NAME) valueName from ehs.ehfm_workflow_mst where workflow_id in (3,4,5) and is_active='true' order by WORKFLOW_NAME ",nativeQuery = true)
	List<CodeValueResult> getWorkflowCat();
	
	@Query(value="select DEPT_ID valueId,upper(DEPT_NAME) valueName from ehs.ehfm_department_mst where is_active='Y' order by DEPT_ORDER",nativeQuery = true)
	List<CodeValueResult> getSubDept();
	
	@Query(value="select eu.login_name emp_code, eu.first_name || eu.last_name emp_name,\r\n"
			+ "edm.desgn_name designation\r\n"
			+ "from \r\n"
			+ "ehs.ehfm_users eu\r\n"
			+ "left join ehs.ehfm_designation_mst edm on eu.desgn_id = edm.desgn_id;",nativeQuery = true)
	List<SentBoxDto2> getempDtls();
	
	 
	@Query(value="select state_id valueId,upper(state_name) valueName from ehs.empnl_state_master where is_state_active='Y'",nativeQuery = true)
	List<CodeValueResult> getState();
	
	@Query(value="select TYPE_ID valueId,upper(TYPE_NAME) valueName from ehs.ehfm_general_type_mst where is_active='Y' AND TYPE_ID=38 order by TYPE_ORDER",nativeQuery = true)
	List<CodeValueResult> getAppType();
	
	
	@Query(value="select gt1.type_name apptype,em.module_name crmodule,gt2.type_name RequestType,crd.cr_title CRtitle,crd.cr_desc CRdesc,gt3.type_name typeofchange,gt4.type_name CRseverity,ewi.workflow_name workflowname,map.attch_file_dtls files,crd.remarks remarks\r\n"
			+ "from ehs.ehfm_change_req_dtls crd left join ehs.ehfm_general_type_mst gt1\r\n"
			+ "on crd.appln_type = gt1.type_id left join ehs.ehfm_module_mst em\r\n"
			+ "on crd.cr_module = em.module_id left join ehs.ehfm_general_type_mst gt2\r\n"
			+ "on crd.change_req_type =gt2.type_id left join ehs.ehfm_general_type_mst gt3\r\n"
			+ "on crd.type_of_change = gt3.type_id left join ehs.ehfm_general_type_mst gt4\r\n"
			+ "on crd.cr_severity =gt4.type_id left join ehs.ehfm_workflow_mst ewi\r\n"
			+ "on crd.workflow_cat = ewi.workflow_id left join ehs.ehfm_cr_attachments_mapping map\r\n"
			+ "on crd.cr_req_id = map.cr_req_id\r\n"
			+ "where\r\n"
			+ "crd.cr_req_id=:crReqId",nativeQuery = true)
	List<SentBox6> Changerequest(@Param("crReqId") Integer crReqId);
	
	
	
}
