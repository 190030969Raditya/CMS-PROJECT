package in.kpmg.cmsapi.DTO;

import lombok.Data;

@Data
public class EHFM_CR_ATTACHMENTS_MAPPING_DTO {
	
	private Long crReqId;
	

}
