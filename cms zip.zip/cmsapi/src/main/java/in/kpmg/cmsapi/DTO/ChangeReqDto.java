package in.kpmg.cmsapi.DTO;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public interface ChangeReqDto {
String getemployeecode();
String getactiontakenby();
Number getphonenumber();
String getdesgnname();
String getremarks();
@JsonFormat(pattern="dd-MM-yyyy")
Date getactiontakentime();
String getviewattchments();
String getstatus();
}
