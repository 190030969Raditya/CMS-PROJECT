package in.kpmg.cmsapi.DTO;

import java.sql.Timestamp;
import java.util.Date;
import lombok.Data;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Data
public class EHFM_CHANGE_REQ_DETAILS_DTO 
	{
 private String applnType;
 private String parntOrgId;
 private String subDeptId;
 private String changeReqType;
 private String crTitle;
 private String crDesc;
 private String crModule;
 private String typeOfChange;
 private String workflowCat;
 private String crSeverity;
 private String mobileNo;
 private String crtBy;
 private String updBy;
 private String crStatusId;
 private String crReqCode;
 private String deptName;
}
