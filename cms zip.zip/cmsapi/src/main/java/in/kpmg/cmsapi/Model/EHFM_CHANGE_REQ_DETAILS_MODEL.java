package in.kpmg.cmsapi.Model;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;
@Data
@Entity
@Table(name = "EHFM_CHANGE_REQ_DTLS")
public class EHFM_CHANGE_REQ_DETAILS_MODEL {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.TABLE, generator = "ehfm_change_req_dtls_cr_req_id_seq")
	    @SequenceGenerator(name = "ehfm_change_req_dtls_cr_req_id_seq",sequenceName = "ehfm_change_req_dtls_cr_req_id_seq",allocationSize = 1)
	    private Long CR_REQ_ID;
	
	 private Long PARNT_ORG_ID;
	 @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "APPLN_TYPE", referencedColumnName = "TYPE_ID")
	 private EHFM_GENERAL_TYPE_MST_MODEL APPLN_TYPE;
	 
	 @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "SUB_DEPT_ID", referencedColumnName = "DEPT_ID")
	    private EHFM_DEPARTMENT_MST_MODEL SUB_DEPT_ID;
	 private Long CHANGE_REQ_TYPE;
	 private String CR_TITLE;
	 private String CR_DESC;
	 private Long CR_MODULE;
	 private Long TYPE_OF_CHANGE;
	 private Long WORKFLOW_CAT;
	 private Long CR_SEVERITY;
	 private Long MOBILE_NO;
	 private Long CRT_BY;
	 @CreationTimestamp
	    private Timestamp CRT_ON;
	 private Long UPD_BY;
	 @UpdateTimestamp
	    private Timestamp UPD_ON;
	 private Long CR_STATUS_ID;
	 private String CR_REQ_CODE;
	 private Long CASE_ID;
	 private String REMARKS; 
	 private Date EXPECTED_COMPLETION_DT;
	

}
