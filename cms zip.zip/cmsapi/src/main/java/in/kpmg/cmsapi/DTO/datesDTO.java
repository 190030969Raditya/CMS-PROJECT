package in.kpmg.cmsapi.DTO;

import lombok.Data;

@Data
public class datesDTO {
	public String fromDate;
	public String toDate;

}
