package in.kpmg.cmsapi.DTO;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public interface SentboxDTO {
	 Number getcrReqId();
	 String getCrTitle();
	 String getCrDesc();
	 String getDeptName();
	 @JsonFormat(pattern="dd-MM-yyyy")
	 Timestamp getcrtOn();
	 String getstepName();
	 String gettypeName();
	 String getTypeNames();
	 String getusername();
	 String getworkflowName();
	 @JsonFormat(pattern="dd-MM-yyyy")
	 Timestamp getedt();
	 String getstatus();
}
