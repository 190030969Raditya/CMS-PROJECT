package in.kpmg.cmsapi.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.kpmg.cmsapi.Model.EHFM_DEPARTMENT_MST_MODEL;

@Repository
public interface  EHFM_DEPARTMENT_MST_REPO extends JpaRepository<EHFM_DEPARTMENT_MST_MODEL,Long>
{
	



}
