package in.kpmg.cmsapi.Util;



import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import static in.kpmg.cmsapi.Util.Constants.FILE_STORAGE_LOCATION;
@Component
public class SaveDocumentsUtil {

    public SaveDocumentsUtil() {
    }

    public String saveDocuments(MultipartFile file, String identifier) {
        String fileName = this.getFileName(file, identifier);

        try {
            Files.createDirectories(FILE_STORAGE_LOCATION);
            if (fileName.contains("..")) {
                throw new Exception("Filename contains invalid path");
            } else {
                Path targetLocation = FILE_STORAGE_LOCATION.resolve(fileName);
                Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                return fileName;
            }
        } catch (Exception var5) {
            throw new RuntimeException(var5);
        }
    }

//    public String saveDocuments(MultipartFile file, Long identifier) {
//        HospitalBasicInfoModel hospitalBasicInfoModel1 = this.getEmpanelUtil.getModelwithId(identifier);
//        String fileName = this.getFileName(file, hospitalBasicInfoModel1.getHospitalPan());
//
//        try {
//            Files.createDirectories(FILE_STORAGE_LOCATION);
//            if (fileName.contains("..")) {
//                throw new Exception("Filename contains invalid path");
//            } else {
//                Path targetLocation =FILE_STORAGE_LOCATION.resolve(fileName);
//                Files.copy(file.getInputStream(), targetLocation,StandardCopyOption.REPLACE_EXISTING);
//                return fileName;
//            }
//        } catch (Exception var6) {
//            throw new RuntimeException(var6);
//        }
//    }

    public String getFileName(MultipartFile file, String identifier) {
        return identifier + "-" + StringUtils.cleanPath(file.getOriginalFilename());
    }

    public String saveDocuments(MultipartFile file, String identifier,String fileLocation) {
        String fileName = this.getFileName(file, identifier);
        String Location = String.valueOf(Paths.get(fileLocation));
        final Path filepath = Paths.get(fileLocation);

        try {
            Files.createDirectories(filepath);
            if (fileName.contains("..")) {
                throw new Exception("Filename contains invalid path");
            } else {
                File tmpDir = new File(filepath.toUri());
                Boolean exists = tmpDir.exists();
                Path targetLocation = filepath.resolve(fileName);
                Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                return fileLocation+"/"+fileName;
            }
        } catch (Exception var5) {
            throw new RuntimeException(var5);
        }
    }
}