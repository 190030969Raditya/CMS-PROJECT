package in.kpmg.cmsapi.DTO;

public interface CodeValueResult {
	
	//Number getLabelId();
	Number getValueId();
	String getValueName();
}