package in.kpmg.cmsapi.Service;

import static in.kpmg.cmsapi.Util.Constants.CONTENT_TYPE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.kpmg.cmsapi.DTO.ApiResponse2;
import in.kpmg.cmsapi.DTO.EHFM_CHANGE_REQ_DETAILS_DTO;
import in.kpmg.cmsapi.DTO.EHFM_CR_ATTACHMENTS_MAPPING_DTO;
import in.kpmg.cmsapi.DTO.ManageReqDTO;
import in.kpmg.cmsapi.DTO.ManageReqResult;
import in.kpmg.cmsapi.DTO.MydeptReportDTO;
import in.kpmg.cmsapi.DTO.cmsReportDto;
import in.kpmg.cmsapi.DTO.cmsReportResult;
import in.kpmg.cmsapi.DTO.myDeptReportResult;
import in.kpmg.cmsapi.Model.EHFM_CHANGE_REQ_DETAILS_MODEL;
import in.kpmg.cmsapi.Model.EHFM_CR_ATTACHMENTS_MAPPING_MODEL;
import in.kpmg.cmsapi.Model.EHFM_DEPARTMENT_MST_MODEL;
import in.kpmg.cmsapi.Model.EHFM_GENERAL_TYPE_MST_MODEL;
import in.kpmg.cmsapi.Repository.EHFM_CHANGE_REQ_DETAILS_Repo;
import in.kpmg.cmsapi.Repository.EHFM_CR_ATTACHMENTS_MAPPING_REPO;
import in.kpmg.cmsapi.Repository.EHFM_DEPARTMENT_MST_REPO;
import in.kpmg.cmsapi.Repository.EHFM_GENERAL_TYPE_MST_REPO;
import in.kpmg.cmsapi.Util.SaveDocumentsUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CreateCRService {
	@Autowired
	EHFM_CHANGE_REQ_DETAILS_Repo ehfm_change_req_details_repo;
	@Autowired
	EHFM_DEPARTMENT_MST_REPO ehfm_department_mst_repo;
	@Autowired
	EHFM_GENERAL_TYPE_MST_REPO ehfm_general_mst_repo;
	@Autowired 
	SaveDocumentsUtil saveDocuments;
	@Autowired
	EHFM_CR_ATTACHMENTS_MAPPING_REPO ehfm_cr_attachemnt_mapping_repo;
	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<ManageReqResult> manageRequest(ManageReqDTO request) {

		String nativeQuery ="select \r\n"
				+ "				crd.cr_req_id crReqId,\r\n"
				+ "				crd.cr_title crTitle,\r\n"
				+ "				crd.CR_DESC crDesc,\r\n"
				+ "				crd.expected_completion_dt ecd,\r\n"
				+ "				dm.dept_name deptName,\r\n"
				+ "				crd.crt_on crtOn,\r\n"
				+ "				sm.Step_name crStatus,\r\n"
				+ "				gm.type_name severity,\r\n"
				+ "				gm1.type_name changeType,\r\n"
				+ "				(us.first_name||' '||us.last_name)username,\r\n"
				+ "				wm.WORKFLOW_NAME workflowCat\r\n"
				+ "				from ehs.ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm \r\n"
				+ "				on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\r\n"
				+ "				on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\r\n"
				+ "				on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\r\n"
				+ "				on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\r\n"
				+ "				on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\r\n"
				+ "				on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\r\n"
				+ "				on crd.TYPE_OF_CHANGE = gm1.type_id left join ehs.EHFM_USERS us\r\n"
				+ "				on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\r\n"
				+ "				on crd.WORKFLOW_CAT = wm.WORKFLOW_ID\n"
				+ "where\n";
		
				if(request.getFromDate() != null)
					nativeQuery = nativeQuery + "TO_CHAR(crd.crt_on, 'YYYY-MM-DD') >='"+request.getFromDate()+"'\n";
				if(request.getToDate() != null)
					nativeQuery = nativeQuery + "AND TO_CHAR(crd.crt_on, 'YYYY-MM-DD') <='"+request.getToDate()+"'";
				if(request.getApplnType() != null)
					nativeQuery = nativeQuery + "  AND gtm.TYPE_NAME ='"+request.getApplnType()+"'\n";
				if(request.getOrgName() != null)
					nativeQuery = nativeQuery + "  AND om.ORG_NAME ='"+request.getOrgName()+"'\n";
				if(request.getDeptName() != null)
					nativeQuery = nativeQuery + "  AND dm.DEPT_NAME ='"+request.getDeptName()+"'\n order by crReqId desc";
		
			
			Query query = em.createNativeQuery(nativeQuery, ManageReqResult.class);

		List<ManageReqResult> searchResults = query.getResultList();
				
		return searchResults;
		

	}
	
	
	
	
	
	
	@SuppressWarnings("unchecked")
	public List<cmsReportResult> mycmsreport(cmsReportDto request) {

		String nativeQuery ="select \n"
				+ "crd.cr_req_id crReqId,\n"
				+ "crd.cr_title crTitle,\n"
				+ "crd.CR_DESC crDesc,\n"
				+ "dm.dept_name deptName,\n"
				+ "crd.crt_on crtOn,\n"
				+ "sm.Step_name crStatus,\n"
				+ "gm.type_name severity,\n"
				+ "gm1.type_name changeType,\n"
				+ "(us.first_name||' '||us.last_name)username,\n"
				+ "wm.WORKFLOW_NAME workflowCat\n"
				+ "from ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm \n"
				+ "on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\n"
				+ "on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\n"
				+ "on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\n"
				+ "on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\n"
				+ "on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\n"
				+ "on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\n"
				+ "on crd.CHANGE_REQ_TYPE = gm1.type_id left join ehs.EHFM_USERS us\n"
				+ "on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\n"
				+ "on crd.WORKFLOW_CAT = wm.WORKFLOW_ID\n"
				+ "where\n";
		
				if(request.getFromDate() != null)
					nativeQuery = nativeQuery + "TO_CHAR(crd.crt_on, 'YYYY-MM-DD') >='"+request.getFromDate()+"'\n";
				if(request.getToDate() != null)
					nativeQuery = nativeQuery + "AND TO_CHAR(crd.crt_on, 'YYYY-MM-DD') <='"+request.getToDate()+"'";
				if(request.getState() != null)
					nativeQuery = nativeQuery + "  AND gtm.TYPE_NAME ='"+request.getState()+"'\n";
				
		
			
			Query query = em.createNativeQuery(nativeQuery, cmsReportResult.class);

		List<cmsReportResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	
	
	@SuppressWarnings("unchecked")
	public List<myDeptReportResult> myDeptReport(MydeptReportDTO request) {

		String nativeQuery ="select \n"
				+ "crd.cr_req_id crReqId,\n"
				+ "crd.cr_title crTitle,\n"
				+ "crd.CR_DESC crDesc,\n"
				+ "dm.dept_name deptName,\n"
				+ "crd.crt_on crtOn,\n"
				+ "sm.Step_name crStatus,\n"
				+ "gm.type_name severity,\n"
				+ "gm1.type_name changeType,\n"
				+ "(us.first_name||' '||us.last_name)username,\n"
				+ "wm.WORKFLOW_NAME workflowCat\n"
				+ "from ehfm_change_req_dtls crd left join ehs.EHFM_GENERAL_TYPE_MST gtm \n"
				+ "on crd.APPLN_TYPE = gtm.TYPE_ID left join ehs.EHFM_ORG_MST om\n"
				+ "on crd.PARNT_ORG_ID = om.ORG_ID left join ehs.EHFM_DEPARTMENT_MST dm\n"
				+ "on crd.SUB_DEPT_ID = dm.DEPT_ID left join ehs.EHFM_STEP_ROLE_MAPPING srm\n"
				+ "on crd.CR_STATUS_ID = srm.STEP_ID left join ehs.ehfm_step_mst sm\n"
				+ "on srm.STEP_ID = sm.STEP_ID left join ehs.EHFM_GENERAL_TYPE_MST gm\n"
				+ "on crd.CR_SEVERITY = gm.type_id left join ehs.EHFM_GENERAL_TYPE_MST gm1\n"
				+ "on crd.CHANGE_REQ_TYPE = gm1.type_id left join ehs.EHFM_USERS us\n"
				+ "on crd.crt_by = us.USER_ID left join ehs.EHFM_WORKFLOW_MST wm\n"
				+ "on crd.WORKFLOW_CAT = wm.WORKFLOW_ID\n"
				+ "where\n";
		
				
				if(request.getDept() != null)
					nativeQuery = nativeQuery + "  AND gtm.TYPE_NAME ='"+request.getDept()+"'\n";
				if(request.getState() != null)
					nativeQuery = nativeQuery + "  AND gtm.TYPE_NAME ='"+request.getState()+"'\n";
				
		
			
			Query query = em.createNativeQuery(nativeQuery, myDeptReportResult.class);

		List<myDeptReportResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	
	
	
	
	
	
	
	
	

	
	
	
	public Map<String, Object> initiateApplication() {
        Map<String, Object> response = new HashMap<>();
        response.put("ParentOrganisation", ehfm_change_req_details_repo.getOrgType());
        response.put("Department", ehfm_change_req_details_repo.getDeptType());
        response.put("SubDepartment", ehfm_change_req_details_repo.getSubDept());
        response.put("CRModule", ehfm_change_req_details_repo.getCRModule());
        response.put("Typeofchange", ehfm_change_req_details_repo.getTypeOfChange());
        response.put("WorkflowCategory",ehfm_change_req_details_repo.getWorkflowCat());
        response.put("application type",ehfm_change_req_details_repo.getAppType() );
        response.put("severity type",ehfm_change_req_details_repo.getTypeOfSeverity() );
        response.put("CRId",ehfm_change_req_details_repo.getCRId() );
        response.put("State", ehfm_change_req_details_repo.getState());
        response.put("Department Name", ehfm_change_req_details_repo.getDeptName());
        response.put("Status",ehfm_change_req_details_repo.getStatus() );
        response.put("Employee details", ehfm_change_req_details_repo.getempDtls());
        response.put("profile", ehfm_change_req_details_repo.getProfileData());
        response.put("Expected Delivery date", ehfm_change_req_details_repo.getExpectedDt());
        return response;
    }
	
	
	  public ApiResponse2<String> saveApplicationForm(EHFM_CHANGE_REQ_DETAILS_DTO ehfm_change_req_details_dto)
	  {
		  try {
				EHFM_CHANGE_REQ_DETAILS_MODEL ehfmchangereqdetailsmodel = new EHFM_CHANGE_REQ_DETAILS_MODEL();
				//ehfmchangereqdetailsmodel.setAPPLN_TYPE(Long.valueOf(ehfm_change_req_details_dto.getApplnType()));
				Optional<EHFM_GENERAL_TYPE_MST_MODEL> applnType = ehfm_general_mst_repo.findById(Long.valueOf(ehfm_change_req_details_dto.getApplnType()));
				ehfmchangereqdetailsmodel.setAPPLN_TYPE(applnType.get());
				ehfmchangereqdetailsmodel.setPARNT_ORG_ID(Long.valueOf(ehfm_change_req_details_dto.getParntOrgId()));
			    //optional	ehfmchangereqdetailsmodel.setSUB_DEPT_ID(Long.valueOf(ehfm_change_req_details_dto.getSubDeptId()));
				Optional<EHFM_DEPARTMENT_MST_MODEL> subDeptId = ehfm_department_mst_repo.findById(Long.valueOf(ehfm_change_req_details_dto.getSubDeptId()));
				ehfmchangereqdetailsmodel.setSUB_DEPT_ID(subDeptId.get());
				ehfmchangereqdetailsmodel.setCHANGE_REQ_TYPE(Long.valueOf(ehfm_change_req_details_dto.getChangeReqType()));
				ehfmchangereqdetailsmodel.setCR_TITLE(ehfm_change_req_details_dto.getCrTitle());
				ehfmchangereqdetailsmodel.setCR_DESC(ehfm_change_req_details_dto.getCrDesc());
				ehfmchangereqdetailsmodel.setCR_MODULE(Long.valueOf(ehfm_change_req_details_dto.getCrModule()));
				ehfmchangereqdetailsmodel.setTYPE_OF_CHANGE(Long.valueOf(ehfm_change_req_details_dto.getTypeOfChange()));
				ehfmchangereqdetailsmodel.setWORKFLOW_CAT(Long.valueOf(ehfm_change_req_details_dto.getWorkflowCat()));
				ehfmchangereqdetailsmodel.setCR_SEVERITY(Long.valueOf(ehfm_change_req_details_dto.getCrSeverity()));
				ehfmchangereqdetailsmodel.setMOBILE_NO(Long.valueOf(ehfm_change_req_details_dto.getMobileNo()));
				ehfmchangereqdetailsmodel.setCRT_BY(Long.valueOf(ehfm_change_req_details_dto.getCrtBy()));
				ehfmchangereqdetailsmodel.setUPD_BY(Long.valueOf(ehfm_change_req_details_dto.getUpdBy()));
				ehfmchangereqdetailsmodel.setCR_STATUS_ID(Long.valueOf(ehfm_change_req_details_dto.getCrStatusId()));
				ehfmchangereqdetailsmodel.setCR_REQ_CODE(ehfm_change_req_details_dto.getCrReqCode());

				log.info("Saving change request Details");
				EHFM_CHANGE_REQ_DETAILS_MODEL savedDetails =ehfm_change_req_details_repo.save(ehfmchangereqdetailsmodel);

				log.info("Saved Changed  Details in service. Req ID: "+savedDetails.getCR_REQ_ID());

				return new ApiResponse2<>(true,"Details Saved!","", HttpStatus.OK.value());

			}catch(Exception e) {
				e.printStackTrace();
				return new ApiResponse2<>(false,"Error saving info","",HttpStatus.NO_CONTENT.value());

			}
	  }
	  
	 
	  public Map<String, Object> changeReqTable()
	  {
	        	
	        	Map<String, Object> response = new HashMap<>();
	            response.put("ChangeReqTable", ehfm_change_req_details_repo.getchangeReqTable());
	            
	            return response;
	            }
	  public Map<String, Object> fetchSentboxDetails()
	  {
	        	
	        	Map<String, Object> response = new HashMap<>();
	            response.put("Sentbox", ehfm_change_req_details_repo.getSentbox());
	            
	            return response;
	            }
	  public Map<String, Object> fetctInboxDetails()
	  {
	        	
	        	Map<String, Object> response = new HashMap<>();
	            response.put("Inbox", ehfm_change_req_details_repo.getInbox());
	            
	            return response;
	  }
	 
	  public Map<String, Object> fetchInbox(String fromDate,String toDate)
	  {
	        	
	        	Map<String, Object> response = new HashMap<>();
	            response.put("InboxSearch", ehfm_change_req_details_repo.getInboxData(fromDate,toDate));
	            
	            return response;
	  }
	  public Map<String, Object> fetchSentbox(String fromDate,String toDate)
	  {
	        	
	        	Map<String, Object> response = new HashMap<>();
	            response.put("SentBoxSearch", ehfm_change_req_details_repo.getSentboxData(fromDate,toDate));
	            
	            return response;
	  }
	  public Map<String, Object> changeReq(Integer crReqId) {
	        Map<String, Object> response = new HashMap<>();
	        response.put("ChangeReq", ehfm_change_req_details_repo.Changerequest(crReqId));
	        return response;
	    }
	  
	  public ApiResponse2 supportingdocs(List<MultipartFile> files,EHFM_CR_ATTACHMENTS_MAPPING_DTO ehfm_cr_attachmets_mapping_dto,List<EHFM_CR_ATTACHMENTS_MAPPING_DTO> crdto) {
	        try {
	            for (int i = 0; i < files.size(); i++) {
	            	EHFM_CR_ATTACHMENTS_MAPPING_DTO attachInfoDTO = crdto.get(i);
	                String Location = "";
	                if (!CONTENT_TYPE.contains(files.get(i).getContentType())) {
	                    return new ApiResponse2<>(false, "Incorrect File Format", "", HttpStatus.NO_CONTENT.value());}
	                	if(attachInfoDTO.getCrReqId()==ehfm_cr_attachmets_mapping_dto.getCrReqId()) {
//	                	Location = "C:\\multipart\\attachment";
	                    Location = "/home/kpmg/cms_supp_docs";
	                    String fileName = saveDocuments.saveDocuments(files.get(i), String.valueOf(ehfm_cr_attachmets_mapping_dto.getCrReqId()), Location);
	                    EHFM_CR_ATTACHMENTS_MAPPING_MODEL ehfm_cr_attachmets_mapping_model=new EHFM_CR_ATTACHMENTS_MAPPING_MODEL();
	                    ehfm_cr_attachmets_mapping_model.setATTCH_FILE_DTLS(fileName);//from data base
	                    ehfm_cr_attachmets_mapping_model.setCR_REQ_ID(Long.valueOf(ehfm_cr_attachmets_mapping_dto.getCrReqId()));//setReqid
	                    ehfm_cr_attachemnt_mapping_repo.save(ehfm_cr_attachmets_mapping_model);
	                	}
	            }
	        } 
	        catch (Exception e) {
	            e.printStackTrace();
	            return new ApiResponse2<>(false, e.getMessage(), "Error saving file !", HttpStatus.INTERNAL_SERVER_ERROR.value());
	        }
	        return new ApiResponse2<>(true, "Documents Saved", "req id:-"+ehfm_cr_attachmets_mapping_dto.getCrReqId(), HttpStatus.OK.value());

	    }
	  
	  
	  }