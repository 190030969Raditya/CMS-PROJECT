package in.kpmg.cmsapi.Util;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class Constants {
    public static final List<String> CONTENT_TYPE = Arrays.asList("application/pdf", "image/jpeg", "image/png", "image/jpg");

    public static final Path FILE_STORAGE_LOCATION= Paths.get("/home/kpmg/HospitalRegistrationDocs");
}
