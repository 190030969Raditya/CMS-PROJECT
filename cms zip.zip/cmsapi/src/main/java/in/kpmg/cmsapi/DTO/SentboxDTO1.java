package in.kpmg.cmsapi.DTO;

public interface SentboxDTO1 {
	Number getRequestId();
	String getStatus();
}
