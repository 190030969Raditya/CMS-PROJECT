package in.kpmg.cmsapi.DTO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Entity
@Data
public class myDeptReportResult {
	@Id
	private Long crReqId;
	private String crTitle;
	private String crDesc;
	private String deptName;
	private Date crtOn;
	private String crStatus;
	private String severity;
	private String changeType;
	private String username;
	private String workflowCat;
}
