package in.kpmg.cmsapi.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "EHFM_DEPARTMENT_MST")
public class EHFM_DEPARTMENT_MST_MODEL {
	
	@Id
	private Long DEPT_ID;
    private Long IMMDTE_PARNT_DEPT_ID;
    private String DEPT_NAME;
    private String DEPT_CODE;
    private String DEPT_TELUGU_NAME;
    private Boolean IS_ENROLLMENT_APPLICABLE;
    private Boolean IS_CMS_APPLICABLE;
    private Boolean IS_ACTIVE;
    private Long DEPT_ORDER;
	 
}
