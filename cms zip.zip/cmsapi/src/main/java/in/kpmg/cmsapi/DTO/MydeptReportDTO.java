package in.kpmg.cmsapi.DTO;

import lombok.Data;

@Data
public class MydeptReportDTO {
	private String Dept;
	private String State;
}
