package in.kpmg.cmsapi.DTO;

import lombok.Data;

@Data
public class AdvanceReqId {
	public Integer crReqId;
}
