package in.kpmg.cmsapi.DTO;

public interface SentBoxDTO3 {
String getempname();
String getdesgn();
String getusername();
String getEmailId();
Number getMobileNo();
}
