package in.kpmg.cmsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmsapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmsapiApplication.class, args);
	}

}
