package in.kpmg.cmsapi.DTO;

public interface SentBox6 {
String getapptype();
String getcrmodule();
String getreqesttype();
String getcrtitle();
String getcrdesc();
String gettypeofchange();
String getcrseverity();
String getworkflowname();
String getfiles();
String getremarks();

}
